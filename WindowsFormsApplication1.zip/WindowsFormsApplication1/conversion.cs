﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class conversion : Form
    {
        public conversion()
        {
            InitializeComponent();
        }

        

        public  void button1_Click(object sender, EventArgs e)
        {
            double temp;
            temp = Convert.ToInt32(textBox1.Text);
           if(checkBox1.Checked){

                double uperstream = temp*9/5+32;
                
              textBox2.Text =uperstream.ToString();
            }
           if(checkBox2.Checked) {

                double  a =Convert.ToInt32(temp-32);
               double b =  a * 5 / 9;
                textBox2.Text = b.ToString();

            }
           if (checkBox1.Checked && checkBox2.Checked) { textBox2.Text = " Double check First "; }
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double Meter;
            Meter = Convert.ToInt32(textBox4.Text);
            if (checkBox4.Checked)
            {

                double cm = Meter * 100;
                textBox3.Text = cm.ToString(); 
                
            }
            if (checkBox3.Checked)
            {

                double km = Meter / 1000;
                textBox3.Text = km.ToString();

            }
            if (checkBox3.Checked && checkBox4.Checked) { textBox3.Text = " Double check First "; }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            double MG;
            MG = Convert.ToInt32(textBox6.Text);
            if (checkBox6.Checked)
            {

                double G= MG / 1000;
                textBox5.Text = G.ToString();

            }
            if (checkBox5.Checked)
            {

                double KG = MG / 1000;
                textBox5.Text = KG.ToString();

            }
            if (checkBox5.Checked && checkBox6.Checked) { textBox5.Text = " Double check First "; }


        }
    }
}
