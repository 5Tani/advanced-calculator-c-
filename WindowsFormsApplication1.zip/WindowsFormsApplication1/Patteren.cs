﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Patteren : Form
    {
        public Patteren()
        {
            InitializeComponent();
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int a;
            a = Convert.ToInt32(textBox1.Text);  
            foreach (var item in GetCalculatedFibonacciSequence(a).Skip(0).Take(100))
            {
                listBox1.Items.Add(item); 
            }
        }
        public static IEnumerable<int> GetCalculatedFibonacciSequence(int a)
        {
            

            int current=a;
            var b =0;
            var next = 0;
            yield return next;
            yield return current;
            while (true)
            {
                next = current + b;
                yield return next;
                b = current;
                current = next;
            }


            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();       
            int num = Convert.ToInt32(textBox1.Text);
            int width = num+num*2;
            listBox1.Items.Add(width);
             width = num + num+num +width*3565;
            listBox1.Items.Add(width);
            width = num + num + num+num+num+width*5999;
            listBox1.Items.Add(width);
            width = num + num + num + num + num + width*89999;
            listBox1.Items.Add(width);

        }

      public  void button3_Click(object sender, EventArgs e)
        {
         
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int number;
            number = Convert.ToInt32(textBox1.Text);
            for(int i = 0; i < number; i++)
            {
                listBox1.Items.Add(Math.Pow(i,i));

            }
        
    }
    }

}
