﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Timer timer = new Timer();

        public Form1()
        {
            InitializeComponent();

            // Frustrating that VS is by default cutting off the bottom. Weird.
            this.Height = 544;
            // Give dropdowns some context
            
        }

        private void btnWasClicked(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string output;
            if (this.is_operator(btn.Text))
            {
                output = " " + btn.Text + " ";
            }
            else
            {
                output = btn.Text;
            }

            updateDisplay(output);

        }

        private void updateDisplay(string update, Boolean replace = false)
        {
            if (display.Text == "0" || replace)
            {
                display.Text = update;
            }
            else
            {
                display.Text += update;
            }

        }
      
        public bool is_operator(string thing)
        {
            string[] operands = new String[] { "+", "-", "^", "*", "/" };
            return operands.Contains(thing);
        }

        private void calculateBtn(object sender, EventArgs e)
        {
            String input = display.Text;
            if (input.Contains('^'))
            {
                int index = input.IndexOf('^');
                try
                {
                    double num1 = Convert.ToDouble(input.Substring(0, index));
                    double num2 = Convert.ToDouble(input.Substring(index + 1));
                    display.Text = Convert.ToString(Math.Pow(num1, num2));
                }
                catch (Exception )
                {
                    MessageBox.Show("An error occured! Please make sure that the input is valid");
                }
            }
            else
            {
                try
                {
                    var something = new DataTable().Compute(input, null);
                    display.Text = Convert.ToString(something);
                }
                catch (Exception)
                {
                    MessageBox.Show("An error occured! Please make sure that the input is valid");
                }
            }

        }


        public void deleteWasClicked(object sender, EventArgs e)
        {
            bool actually_deleted_something = false;
            // in case there's white space happening, we need recursion here
            while (display.Text.Length > 0)
            {
                string nextChar = display.Text.Substring(display.Text.Length - 1);
                if (nextChar != " ")
                {
                    if (actually_deleted_something)
                    {
                        break;
                    }
                    actually_deleted_something = true;
                }
                display.Text = display.Text.Substring(0, display.Text.Length - 1);
            }


            // this must not be an else statement, because both might be true 
            if (display.Text.Length == 0)
            {
                display.Text = "0";
            }
        }

        // When they press down the mouse, wait 3/4 of a second to see if they are
        // still holding down on it. If so, then execute a function 
        private void btnClear_MouseDown(object sender, MouseEventArgs e)
        {
            timer.Tick += new EventHandler(emptyOutput);
            timer.Interval = 750;
            timer.Enabled = true;
            timer.Start();
        }

        // When they press back up from the mouse, turn off the flag that's storing this
        // and then stop the timer
        private void btnClear_MouseUp(object sender, MouseEventArgs e)
        {
            timer.Stop();
        }

        // If the user is pressing down when this fires, clear the output
        void emptyOutput(object sender, EventArgs e)
        {
                display.Text = "0";
        }

        public String[] months()
        {
            String[] days = new String[12];
            for (int i = 1; i <= 12; i++)
            {
                days[i - 1] = i < 10 ? "0" + Convert.ToString(i) : Convert.ToString(i);
            }
            return days;
        }

        public String[] years()
        {
            return days();
        }

        public String[] days()
        {
            String[] days = new String[31];
            for (int i = 1; i <= 31; i++)
            {
                days[i - 1] = i < 10 ? "0" + Convert.ToString(i) : Convert.ToString(i);
            }
            return days;
        }

        public String[] hours()
        {
            String[] hours = new String[12];
            for (int i = 1; i <= 12; i++)
            {
                hours[i - 1] = Convert.ToString(i);
            }
            return hours;
        }

        public String[] minutes()
        {
            String[] minutes = new String[60];
            for (int i = 0; i <= 59; i++)
            {
                minutes[i] = i < 10 ? "0" + Convert.ToString(i) : Convert.ToString(i);
            }
            return minutes;
        }

        private void Regtbn_Click(object sender, EventArgs e)
        {

            Form1 obj = new Form1();
            obj.Show();
            obj.Close();                            
        }

        private void Advbtn_Click(object sender, EventArgs e)
        {
            advance obj = new advance();
            obj.Show(); 
        }

        private void Patbtn_Click(object sender, EventArgs e)
        {  
            
            Patteren obj = new Patteren();
             obj.Show();
        }

        private void Conbtn_Click(object sender, EventArgs e)
        {
            conversion obj = new conversion();
            obj.Show(); 
        }
    }
}
